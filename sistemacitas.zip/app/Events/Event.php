<?php

namespace sistemacitas\Events;

abstract class Event
{
    //
}
